/* Basic NDT PRO 2026-11-04. Cache only the public app shell, never inspection records. */
const CACHE='basic-ndt-pro-shell-ux-2026-11-04-v1';
const SHELL=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install', event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate', event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(x=>x.startsWith('basic-ndt-pro-shell-')&&x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
 if(req.mode==='navigate'){
  event.respondWith(fetch(req).then(response=>{if(response.ok)caches.open(CACHE).then(c=>c.put('./index.html',response.clone())).catch(()=>{});return response}).catch(()=>caches.match('./index.html')));return;
 }
 event.respondWith(caches.match(req).then(found=>found||fetch(req).then(res=>{if(res.ok&&SHELL.some(p=>new URL(p,self.registration.scope).pathname===new URL(req.url).pathname))caches.open(CACHE).then(c=>c.put(req,res.clone())).catch(()=>{});return res})));
});