import assert from 'node:assert/strict';
import {STATUS,sourceActivityCi,inverseSquareFactor,interpolateLogExposure,gammaExposureResearchOnly,FILM_FACTORS} from './rt-research-utils.mjs';
assert.equal(STATUS,'NOT_FIELD_VALIDATED');
assert(Math.abs(sourceActivityCi(40,119.781,'Se-75')-20)<1e-9);
assert(Math.abs(sourceActivityCi(36,73.827,'Ir-192')-18)<1e-9);
assert.equal(inverseSquareFactor(500,1000),.25);
assert.equal(inverseSquareFactor(2000,1000),4);
assert.equal(FILM_FACTORS['Se-75'].D4,2.4);
assert.equal(FILM_FACTORS['Ir-192'].D4,3);
const synthetic=[{thickness_mm:10,exposure_Ci_h_at_1m:1},{thickness_mm:20,exposure_Ci_h_at_1m:100}];
assert(Math.abs(interpolateLogExposure(synthetic,15)-10)<1e-10);
assert.throws(()=>interpolateLogExposure(synthetic,25),/no extrapolation/);
assert.throws(()=>gammaExposureResearchOnly({isotope:'Se-75',film:'D5',steelMm:15,distanceMm:500,activityCi:36,approvedCurve:synthetic,densityFactor:1,targetDensity:2.0}),/NOT_FIELD_VALIDATED/);
assert.throws(()=>gammaExposureResearchOnly({isotope:'Se-75',film:'D5',steelMm:15,distanceMm:500,activityCi:36,approvedCurve:[],densityFactor:1,targetDensity:2.0,fieldValidated:true}),/Missing independently verified/);
// The synthetic data above tests math only; they are NOT actual radiographic chart points.
console.log('10 controles geslaagd. Formules getest met SYNTHETISCHE punten, geen vrijgegeven RT-berekening.');
