/** Basic NDT PRO RT research utilities, not a field-released exposure calculator. */
export const STATUS = 'NOT_FIELD_VALIDATED';
export const HALF_LIFE_DAYS = Object.freeze({'Se-75':119.781,'Ir-192':73.827,'Co-60':1925.3});
export const FILM_FACTORS = Object.freeze({'Se-75':{D4:2.4,D5:1.4,D7:1},'Ir-192':{D4:3,D5:1.5,D7:1},'Co-60':{D4:3,D5:1.5,D7:1}});
function positive(x,label){if(!Number.isFinite(x)||x<=0)throw new RangeError(label+' must be positive and finite');return x;}
export function sourceActivityCi(activityAtAssayCi,daysElapsed,isotope){
 positive(activityAtAssayCi,'activityAtAssayCi');
 if(!Number.isFinite(daysElapsed)||daysElapsed<0)throw new RangeError('daysElapsed must be finite and non-negative');
 const halfLife=HALF_LIFE_DAYS[isotope];if(!halfLife)throw new RangeError('isotope not supported');
 return activityAtAssayCi*Math.pow(2,-daysElapsed/halfLife);
}
export function inverseSquareFactor(distanceMm,referenceMm=1000){return Math.pow(positive(distanceMm,'distanceMm')/positive(referenceMm,'referenceMm'),2);}
export function interpolateLogExposure(points,steelMm){
 if(!Array.isArray(points)||points.length<2||!Number.isFinite(steelMm))throw new RangeError('two verified curve points and steelMm required');
 for(let i=0;i<points.length;i++){
   if(!Number.isFinite(points[i].thickness_mm)||!Number.isFinite(points[i].exposure_Ci_h_at_1m)||points[i].exposure_Ci_h_at_1m<=0)throw new RangeError('invalid curve point');
   if(i&&points[i-1].thickness_mm>=points[i].thickness_mm)throw new RangeError('curve points must be strictly increasing');
 }
 if(steelMm<points[0].thickness_mm||steelMm>points.at(-1).thickness_mm)throw new RangeError('outside digitized curve range; no extrapolation');
 for(let i=1;i<points.length;i++){
  const a=points[i-1],b=points[i];if(steelMm>=a.thickness_mm&&steelMm<=b.thickness_mm){
   const q=(steelMm-a.thickness_mm)/(b.thickness_mm-a.thickness_mm);
   return Math.exp(Math.log(a.exposure_Ci_h_at_1m)*(1-q)+Math.log(b.exposure_Ci_h_at_1m)*q);
  }
 }
 throw new RangeError('curve has a gap');
}
export function gammaExposureResearchOnly({isotope,film,targetDensity,steelMm,distanceMm,activityCi,approvedCurve,densityFactor,fieldValidated=false}){
 if(!fieldValidated)throw new Error('NOT_FIELD_VALIDATED: research curves are not released for RT exposures');
 if(!Array.isArray(approvedCurve)||approvedCurve.length<2)throw new Error('Missing independently verified base exposure curve');
 if(!Number.isFinite(densityFactor)||densityFactor<=0)throw new Error('Missing independently validated film density factor');
 if(!FILM_FACTORS[isotope]?.[film])throw new Error('No manufacturer film factor for this isotope/film');
 if(!Number.isFinite(targetDensity))throw new RangeError('targetDensity required');
 // Chart convention: gamma base exposure at D2 and SFD 1m, unit Ci-hour.
 const baseCiH=interpolateLogExposure(approvedCurve,steelMm);
 return baseCiH*60*FILM_FACTORS[isotope][film]*densityFactor*inverseSquareFactor(distanceMm)/positive(activityCi,'activityCi');
}
